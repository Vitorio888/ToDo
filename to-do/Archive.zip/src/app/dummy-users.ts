export const DUMMY_USERS = [
  {
    id: 'u1',
    name: 'Gandi',
    avatar: 'user-1.jpg'
  },
  {
    id: 'u2',
    name: 'Alex',
    avatar: 'user-2.jpg'
  },
  {
    id: 'u3',
    name: 'Susana',
    avatar: 'user-3.jpg'
  },
]