import { Component } from '@angular/core';

@Component({
  selector: 'app-tasks-view',
  standalone: true,
  imports: [],
  templateUrl: './tasks-view.component.html',
  styleUrl: './tasks-view.component.css',
})
export class TasksViewComponent {}
