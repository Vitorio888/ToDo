export const DATA_MULTI_TASK = [
  {
    id: '1',
    userName: 'Gio',
    taskName: 'Task1',
    status: 'todo',
  },
  {
    id: '2',
    userName: 'Misha',
    taskName: 'Task2',
    status: 'todo',
  },
  {
    id: '3',
    userName: 'Mariam',
    taskName: 'Task3',
    status: 'todo',
  },
]